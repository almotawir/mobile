package com.semenog.game.tetris;

//import android.util.Log;
import android.view.SurfaceHolder;

public class SurfaceHolderCallbacks implements SurfaceHolder.Callback {

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}

	

	


}
